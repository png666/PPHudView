//
//  PPHudView.h
//  PPHud
//
//  Created by macfai on 16/2/25.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PPHudView : UIView

+(PPHudView *)sharedHud;

+(void)show;
+(void)dismiss;

@end
