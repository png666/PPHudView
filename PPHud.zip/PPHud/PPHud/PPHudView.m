

//
//  PPHudView.m
//  PPHud
//
//  Created by macfai on 16/2/25.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "PPHudView.h"

@interface PPHudView()

@property(nonatomic,strong)UIView *hudView;
@property(nonatomic,strong)UIActivityIndicatorView *indicatorView;
@property(nonatomic,strong)UILabel *hudLabel;

@end

@implementation PPHudView

+(PPHudView *)sharedHud{
    
    static PPHudView *_hud = nil;
    static dispatch_once_t t;
    dispatch_once(&t, ^{
        _hud = [[PPHudView alloc]init];
    });
    return _hud;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

+(void)show{
    
    [[self sharedHud]showHud];
}

+(void)dismiss{
    
    [[self sharedHud]removeHudUI];
}

-(void)setBgView{
    //清除整个背景色
    self.backgroundColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1];
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    
}

-(void)makeHudUI{
    
    _hudView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 90, 90)];
    _hudView.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height/2);
    _hudView.backgroundColor = [UIColor grayColor];
    _hudView.layer.cornerRadius = 4;
    _hudView.layer.masksToBounds = YES;
    _hudView.alpha = .8;
    [self addSubview:_hudView];
    
    _indicatorView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:0];
    _indicatorView.frame = CGRectMake(30, 20, 30, 30);
    [_hudView addSubview:_indicatorView];
    [_indicatorView startAnimating];
    
    _hudLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 50, 90, 50)];
    _hudLabel.text = @"数据处理中";
    _hudLabel.textAlignment = NSTextAlignmentCenter;
    _hudLabel.font = [UIFont systemFontOfSize:14];
    _hudLabel.textColor = [UIColor whiteColor];
    
    [_hudView addSubview:_hudLabel];
    
}

-(void)removeHudUI{
    
    [self removeFromSuperview];
    [_indicatorView stopAnimating];
}

-(void)showHud{
    
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [self makeHudUI];
    [self setBgView];
    
}


@end
